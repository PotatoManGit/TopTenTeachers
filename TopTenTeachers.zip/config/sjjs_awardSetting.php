<?php
/**
 * 配置奖项信息
 */

return [
    'awardNum' => 10,
    'award1' => '奖项1',
    'award2' => '奖项2',
    'award3' => '奖项3',
    'award4' => '奖项4',
    'award5' => '奖项5',
    'award6' => '奖项6',
    'award7' => '奖项7',
    'award8' => '奖项8',
    'award9' => '奖项9',
    'award10' => '奖项10'
];
