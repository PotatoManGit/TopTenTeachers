<?php
return [
  'teacherTypeNum' => 6,

  'teacherType1' => [
      'typeKey' => array('语文'),
      'typeName' => '语文老师'
  ],

  'teacherType2' => [
      'typeKey' => array('英语'),
      'typeName' => '英语老师'
  ],

  'teacherType3' => [
      'typeKey' => array('数学'),
      'typeName' => '数学老师'
  ],

  'teacherType4' => [
      'typeKey' => array('物理'),
      'typeName' => '物理老师'
  ],

  'teacherType5' => [
      'typeKey' => array('化学'),
      'typeName' => '化学老师'
  ],

  'teacherType6' => [
      'typeKey' => array('生物'),
      'typeName' => '生物老师'
  ],
];
