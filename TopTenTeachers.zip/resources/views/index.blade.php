@extends("layout")

@section("content")
    <head>
        <meta charset="UTF-8">
        <title>十佳教师评选</title>
    </head>
    <div style="text-align: center">
        <div class="jumbotron">
            <h1>交大附中十佳教师评选</h1>
            <p>欢迎使用交大附中十佳教师评选系统</p>
            <p><a class="btn btn-primary btn-lg" target="_blank" href="http://sjjs.doc.ziyustudio.com/" role="button">查看使用说明</a></p>
        </div>
    </div>


@stop
